import React, { useState, useEffect } from 'react';
import {
  X, Plane, Clock, MapPin, Filter, ChevronDown, ChevronUp, Wifi, Coffee, Utensils, Star, Info
} from 'lucide-react';

// Date formatting function
const formatDateDisplay = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, '0');
  const monthNames = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const month = monthNames[date.getMonth()];
  const year = date.getFullYear();
  return `${day} ${month} ${year}`;
};

interface FlightSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onFlightSelect: (flight: any, direction: 'outbound' | 'return') => void;
  onContinue?: (selections: { outbound: any; return: any | null }) => void;
  searchData: {
    from: string;
    to: string;
    departureDate: string;
    returnDate?: string;
    tripType: 'one-way' | 'round-trip';
    passengers?: {
      adults: number;
      children: number;
      infants: number;
    };
    travelClass?: 'economy' | 'premium' | 'business' | 'first';
  };
}

interface Flight {
  id: string;
  airline: {
    code: string;
    name: string;
    logo: string;
  };
  flightNumber: string;
  aircraft: string;
  departure: {
    airport: string;
    city: string;
    time: string;
    terminal?: string;
  };
  arrival: {
    airport: string;
    city: string;
    time: string;
    terminal?: string;
  };
  duration: string;
  stops: number;
  stopDetails?: {
    airport: string;
    duration: string;
  }[];
  price: {
    economy: number;
    premium: number;
    business: number;
  };
  availableFareTypes: {
    corporate?: { price: number; features: string[] };
    flexi?: { price: number; features: string[] };
    retail?: { price: number; features: string[] };
  };
  amenities: string[];
  baggage: {
    checkedBag: string;
    handBag: string;
  };
  refundable: boolean;
  seatsLeft: number;
}

// Generate flight data with comprehensive details
const generateFlights = (from: string, to: string): Flight[] => {
  const airlines = [
    { code: '6E', name: 'IndiGo', logo: '🔵' },
    { code: 'SG', name: 'SpiceJet', logo: '🌶️' },
    { code: 'AI', name: 'Air India', logo: '🇮🇳' },
    { code: 'UK', name: 'Vistara', logo: '✈️' }
  ];

  const aircraftTypes = ['Boeing 737', 'Airbus A320', 'Boeing 777', 'Airbus A380'];
  const amenities = ['WiFi', 'Meal', 'Entertainment', 'Power', 'Extra Legroom'];

  const flights: Flight[] = [];
  
  for (let i = 0; i < 15; i++) {
    const airline = airlines[i % airlines.length];
    const isInternational = from.includes('International') || to.includes('International');
    const basePrice = isInternational ? 25000 + Math.random() * 50000 : 3000 + Math.random() * 12000;
    
    const departureHour = Math.floor(Math.random() * 24);
    const departureMinute = Math.floor(Math.random() * 60);
    const durationHours = isInternational ? 6 + Math.random() * 8 : 1 + Math.random() * 4;
    const durationMinutes = Math.floor((durationHours % 1) * 60);
    const durationHoursInt = Math.floor(durationHours);
    
    const totalMinutes = departureHour * 60 + departureMinute + durationHoursInt * 60 + durationMinutes;
    const arrivalHour = Math.floor(totalMinutes / 60) % 24;
    const arrivalMinute = totalMinutes % 60;

    const stops = Math.random() < 0.6 ? 0 : Math.random() < 0.8 ? 1 : 2;
    
    // Generate fare types based on airline
    const fareTypes: any = {};
    switch (airline.name) {
      case 'IndiGo':
        fareTypes.corporate = {
          price: Math.floor(basePrice * 0.85),
          features: ['15% corporate discount', 'Free date changes', 'Priority check-in']
        };
        fareTypes.retail = {
          price: Math.floor(basePrice),
          features: ['Standard published fare', 'Change fees apply']
        };
        break;
      case 'Vistara':
        fareTypes.corporate = {
          price: Math.floor(basePrice * 0.88),
          features: ['12% corporate savings', 'Free changes', 'Lounge access']
        };
        fareTypes.flexi = {
          price: Math.floor(basePrice * 0.98),
          features: ['Flexible dates', 'Free cancellation']
        };
        fareTypes.retail = {
          price: Math.floor(basePrice),
          features: ['Standard fare', 'Paid changes allowed']
        };
        break;
      default:
        fareTypes.corporate = {
          price: Math.floor(basePrice * 0.90),
          features: ['Corporate discount', 'Free changes']
        };
        fareTypes.retail = {
          price: Math.floor(basePrice),
          features: ['Standard fare', 'Basic service']
        };
    }
    
    const flight: Flight = {
      id: `flight-${i}`,
      airline,
      flightNumber: `${airline.code} ${1000 + i}`,
      aircraft: aircraftTypes[Math.floor(Math.random() * aircraftTypes.length)],
      departure: {
        airport: from.split(' - ')[0] || 'BOM',
        city: from.split(' - ')[1] || 'Mumbai',
        time: `${departureHour.toString().padStart(2, '0')}:${departureMinute.toString().padStart(2, '0')}`,
        terminal: Math.random() < 0.5 ? `${Math.floor(Math.random() * 3) + 1}` : undefined
      },
      arrival: {
        airport: to.split(' - ')[0] || 'DEL',
        city: to.split(' - ')[1] || 'Delhi',
        time: `${arrivalHour.toString().padStart(2, '0')}:${arrivalMinute.toString().padStart(2, '0')}`,
        terminal: Math.random() < 0.5 ? `${Math.floor(Math.random() * 3) + 1}` : undefined
      },
      duration: `${durationHoursInt}h ${durationMinutes}m`,
      stops,
      stopDetails: stops > 0 ? Array.from({ length: stops }, () => ({
        airport: ['BLR', 'HYD', 'MAA', 'CCU'][Math.floor(Math.random() * 4)],
        duration: `${Math.floor(1 + Math.random() * 3)}h ${Math.floor(Math.random() * 60)}m`
      })) : undefined,
      price: {
        economy: Math.floor(basePrice),
        premium: Math.floor(basePrice * 1.5),
        business: Math.floor(basePrice * 2.5)
      },
      amenities: amenities.filter(() => Math.random() < 0.6),
      baggage: {
        checkedBag: '15 kg',
        handBag: '7 kg'
      },
      refundable: Math.random() < 0.3,
      seatsLeft: Math.floor(1 + Math.random() * 20),
      availableFareTypes: fareTypes
    };
    
    flights.push(flight);
  }
  
  return flights.sort((a, b) => a.price.economy - b.price.economy);
};

const FlightSearchModal: React.FC<FlightSearchModalProps> = ({
  isOpen,
  onClose,
  onFlightSelect,
  onContinue,
  searchData
}) => {
  const [outboundFlights, setOutboundFlights] = useState<Flight[]>([]);
  const [returnFlights, setReturnFlights] = useState<Flight[]>([]);
  const [filteredFlights, setFilteredFlights] = useState<Flight[]>([]);
  const [selectedFare, setSelectedFare] = useState<'economy' | 'premium' | 'business'>('economy');
  const [sortBy, setSortBy] = useState<'price' | 'duration' | 'departure'>('departure');
  const [filters, setFilters] = useState({
    maxPrice: 50000,
    airlines: [] as string[],
    stops: 'non-stop' as 'all' | 'non-stop' | '1-stop' | '2+stops',
    departureTime: 'all' as 'all' | 'morning' | 'afternoon' | 'evening' | 'night',
    refundable: false
  });
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(false);
  const [tooltipVisible, setTooltipVisible] = useState<string | null>(null);
  const [selectedOutbound, setSelectedOutbound] = useState<Flight | null>(null);
  const [selectedReturn, setSelectedReturn] = useState<Flight | null>(null);
  const [selectedFlight, setSelectedFlight] = useState<{flight: Flight; fareType: string; price: number} | null>(null);

  useEffect(() => {
    if (isOpen) {
      setLoading(true);
      setSelectedOutbound(null);
      setSelectedReturn(null);
      setTimeout(() => {
        const generatedOutbound = generateFlights(searchData.from, searchData.to);
        const generatedReturn = searchData.tripType === 'round-trip'
          ? generateFlights(searchData.to, searchData.from)
          : [];
        setOutboundFlights(generatedOutbound);
        setReturnFlights(generatedReturn);
        setFilteredFlights(generatedOutbound);
        setLoading(false);
      }, 1000);
    }
  }, [isOpen, searchData]);

  useEffect(() => {
    let filtered = [...outboundFlights];
    filtered = filtered.filter(flight => flight.price[selectedFare] <= filters.maxPrice);
    if (filters.airlines.length > 0) {
      filtered = filtered.filter(flight => filters.airlines.includes(flight.airline.code));
    }
    if (filters.stops !== 'all') {
      filtered = filtered.filter(flight => {
        switch (filters.stops) {
          case 'non-stop': return flight.stops === 0;
          case '1-stop': return flight.stops === 1;
          case '2+stops': return flight.stops >= 2;
          default: return true;
        }
      });
    }
    if (filters.departureTime !== 'all') {
      filtered = filtered.filter(flight => {
        const hour = parseInt(flight.departure.time.split(':')[0]);
        switch (filters.departureTime) {
          case 'morning': return hour >= 6 && hour < 12;
          case 'afternoon': return hour >= 12 && hour < 18;
          case 'evening': return hour >= 18 && hour < 24;
          case 'night': return hour >= 0 && hour < 6;
          default: return true;
        }
      });
    }
    if (filters.refundable) {
      filtered = filtered.filter(flight => flight.refundable);
    }
    switch (sortBy) {
      case 'price':
        filtered.sort((a, b) => a.price[selectedFare] - b.price[selectedFare]);
        break;
      case 'duration':
        filtered.sort((a, b) => {
          const aDuration = parseInt(a.duration.split('h')[0]) * 60 + parseInt(a.duration.split('h')[1].split('m')[0]);
          const bDuration = parseInt(b.duration.split('h')[0]) * 60 + parseInt(b.duration.split('h')[1].split('m')[0]);
          return aDuration - bDuration;
        });
        break;
      case 'departure':
        filtered.sort((a, b) => a.departure.time.localeCompare(b.departure.time));
        break;
    }
    setFilteredFlights(filtered);
  }, [outboundFlights, filters, selectedFare, sortBy]);

  // Generate flight data with focus on IndiGo and SpiceJet
  const generateFlights = () => {
    const airlines = [
      { code: '6E', name: 'IndiGo', logo: '🔵' },
      { code: 'SG', name: 'SpiceJet', logo: '🌶️' },
      { code: 'AI', name: 'Air India', logo: '🇮🇳' },
      { code: 'UK', name: 'Vistara', logo: '✈️' }
    ];

    const aircraftTypes = ['Boeing 737', 'Airbus A320', 'Boeing 777', 'Airbus A380', 'Boeing 787', 'Airbus A330'];
    const amenities = ['wifi', 'meal', 'entertainment', 'power', 'extra-legroom'];

    const mockFlights: Flight[] = [];
    
    // Generate more IndiGo and SpiceJet flights
    for (let i = 0; i < 20; i++) {
      const airline = i < 8 ? airlines[0] : i < 14 ? airlines[1] : airlines[Math.floor(Math.random() * airlines.length)];
      const isInternational = searchData.from.includes('International') || searchData.to.includes('International');
      const basePrice = isInternational ? 25000 + Math.random() * 75000 : 3000 + Math.random() * 15000;
      
      const departureHour = Math.floor(Math.random() * 24);
      const durationHours = isInternational ? 6 + Math.random() * 12 : 1 + Math.random() * 4;
      const arrivalHour = (departureHour + durationHours) % 24;

      const stops = Math.random() < 0.4 ? 0 : Math.random() < 0.7 ? 1 : 2;
      
      mockFlights.push({
        id: `flight-${i}`,
        airline,
        flightNumber: `${airline.code}${Math.floor(100 + Math.random() * 900)}`,
        aircraft: aircraftTypes[Math.floor(Math.random() * aircraftTypes.length)],
        departure: {
          airport: searchData.from.split(' - ')[0],
          city: searchData.from.split(' - ')[1] || 'City',
          time: `${departureHour.toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
          terminal: Math.random() < 0.5 ? `T${Math.floor(1 + Math.random() * 3)}` : undefined
        },
        arrival: {
          airport: searchData.to.split(' - ')[0],
          city: searchData.to.split(' - ')[1] || 'City',
          time: `${Math.floor(arrivalHour).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
          terminal: Math.random() < 0.5 ? `T${Math.floor(1 + Math.random() * 3)}` : undefined
        },
        duration: `${Math.floor(durationHours)}h ${Math.floor((durationHours % 1) * 60)}m`,
        stops,
        stopDetails: stops > 0 ? Array.from({ length: stops }, (_, idx) => ({
          airport: `CON${idx + 1}`,
          duration: `${Math.floor(1 + Math.random() * 3)}h ${Math.floor(Math.random() * 60)}m`
        })) : undefined,
        price: {
          economy: Math.floor(basePrice),
          premium: Math.floor(basePrice * 1.5),
          business: Math.floor(basePrice * 2.5)
        },
        amenities: amenities.filter(() => Math.random() < 0.6).map(a => a.charAt(0).toUpperCase() + a.slice(1)),
        baggage: {
          checkedBag: '15 kg',
          handBag: '7 kg'
        },
        refundable: Math.random() < 0.3,
        seatsLeft: Math.floor(1 + Math.random() * 20),
        availableFareTypes: {
          corporate: {
            price: Math.floor(basePrice * 0.85),
            features: ['15% corporate discount', 'Free date changes', 'Priority check-in']
          },
          retail: {
            price: Math.floor(basePrice),
            features: ['Standard published fare', 'Change fees apply']
          }
        }
      });
    }
    
    return mockFlights.sort((a, b) => a.price[selectedFare] - b.price[selectedFare]);
  };





  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi': return <Wifi size={16} />;
      case 'meal': return <Utensils size={16} />;
      case 'entertainment': return <Star size={16} />;
      case 'power': return '⚡';
      case 'extra-legroom': 
      case 'extra legroom': return '💺';
      default: return null;
    }
  };

  // Render flight list component
  const renderFlightList = (flights: Flight[], direction: 'outbound' | 'return' = 'outbound') => {
    console.log('🎨 Rendering flight list:', flights.length, 'flights for', direction);
    
    if (!flights || flights.length === 0) {
      console.log('❌ No flights to render');
      return (
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <Plane size={32} className="text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600 text-sm">No flights available</p>
          </div>
        </div>
      );
    }
    
    return flights.map((flight) => (
      <div key={flight.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
        {/* Flight Details Section - Top */}
        <div className="mb-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="text-2xl">{flight.airline.logo}</div>
            <div>
              <div className="text-sm font-sf-bold text-gray-800">
                {flight.airline.name}
              </div>
              <div className="text-xs text-gray-500">
                {flight.flightNumber} • {flight.aircraft}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between mb-3">
            <div className="text-center">
              <div className="text-lg font-sf-bold text-gray-900">
                {flight.departure.time}
              </div>
              <div className="text-xs text-gray-600">
                {flight.departure.airport}
              </div>
              <div className="text-xs text-gray-500">
                {flight.departure.city}
              </div>
              {flight.departure.terminal && (
                <div className="text-xs text-gray-400">
                  Terminal {flight.departure.terminal}
                </div>
              )}
            </div>

            <div className="flex-1 mx-4">
              <div className="flex items-center justify-center">
                <div className="flex-1 border-t border-gray-300"></div>
                <div className="mx-2 text-center">
                  <div className="text-xs font-sf-medium text-gray-600">{flight.duration}</div>
                  <div className="text-xs text-gray-500">
                    {flight.stops === 0 ? 'Non-stop' : `${flight.stops} stop${flight.stops > 1 ? 's' : ''}`}
                  </div>
                </div>
                <div className="flex-1 border-t border-gray-300"></div>
              </div>
              {flight.stopDetails && flight.stopDetails.length > 0 && (
                <div className="text-xs text-gray-500 text-center mt-1">
                  via {flight.stopDetails[0].airport} ({flight.stopDetails[0].duration})
                </div>
              )}
            </div>

            <div className="text-center">
              <div className="text-lg font-sf-bold text-gray-900">
                {flight.arrival.time}
              </div>
              <div className="text-xs text-gray-600">
                {flight.arrival.airport}
              </div>
              <div className="text-xs text-gray-500">
                {flight.arrival.city}
              </div>
              {flight.arrival.terminal && (
                <div className="text-xs text-gray-400">
                  Terminal {flight.arrival.terminal}
                </div>
              )}
            </div>
          </div>

          {/* Amenities */}
          <div className="flex items-center gap-2 mb-2">
            {flight.amenities.slice(0, 3).map((amenity, idx) => (
              <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded-full">
                {amenity}
              </span>
            ))}
            {flight.amenities.length > 3 && (
              <span className="text-xs text-gray-500">
                +{flight.amenities.length - 3} more
              </span>
            )}
          </div>

          {/* Baggage */}
          <div className="flex items-center gap-4 text-xs text-gray-600">
            <span>✓ {flight.baggage.checkedBag}</span>
            <span>✓ {flight.baggage.handBag}</span>
            {flight.refundable && <span className="text-green-600">✓ Refundable</span>}
          </div>
        </div>

        {/* Fare Type Options - Bottom (Clickable Boxes) */}
        <div className="border-t border-gray-100 pt-3">
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(flight.availableFareTypes || {}).map(([fareType, fareData]) => (
              <div 
                key={fareType} 
                onClick={() => {
                  const selectedFlight = {
                    ...flight,
                    fareType,
                    price: fareData.price
                  };
                  onFlightSelect(selectedFlight, direction);
                  // Modal stays open for user to continue selecting
                }}
                className="relative border border-gray-200 rounded-lg hover:border-orange-300 hover:bg-orange-50 transition-all cursor-pointer p-3 text-center"
              >
                <div className="flex items-center justify-center gap-1 mb-2">
                  <span className="text-xs font-sf-semibold text-gray-800 capitalize">
                    {fareType}
                  </span>
                  {fareType === 'corporate' && (
                    <span className="text-xs bg-green-500 text-white px-1 py-0.5 rounded-full">
                      Rec
                    </span>
                  )}
                  {/* Tooltip Trigger */}
                  <div className="relative">
                    <button
                      onMouseEnter={() => setTooltipVisible(`${flight.id}-${fareType}`)}
                      onMouseLeave={() => setTooltipVisible(null)}
                      onClick={(e) => e.stopPropagation()}
                      className="text-gray-400 hover:text-gray-600 transition-colors"
                    >
                      <Info size={10} />
                    </button>
                    
                    {/* Tooltip Content */}
                    {tooltipVisible === `${flight.id}-${fareType}` && (
                      <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 z-50">
                        <div className="bg-gray-900 text-white text-xs rounded-lg p-3 min-w-[200px] shadow-lg">
                          <div className="font-sf-semibold mb-2 capitalize">{fareType} Benefits:</div>
                          <ul className="space-y-1">
                            {fareData.features.map((feature, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <span className="text-green-400 mt-0.5">•</span>
                                <span>{feature}</span>
                              </li>
                            ))}
                          </ul>
                          {/* Tooltip Arrow */}
                          <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="text-sm font-sf-bold text-gray-900 mb-1">
                  ₹{fareData.price.toLocaleString()}
                </div>
                <div className="text-xs text-gray-500">per person</div>
              </div>
            ))}
          </div>
          {flight.seatsLeft <= 15 && (
            <div className="text-xs text-red-500 font-sf-medium mt-2 text-center">
              {flight.seatsLeft} seats left
            </div>
          )}
        </div>
      </div>
    ));
  };

  // Handle flight selection
  const handleFlightSelection = (flight: Flight, fareType: keyof typeof flight.availableFareTypes) => {
    const fareInfo = flight.availableFareTypes[fareType];
    if (fareInfo) {
      setSelectedFlight({
        flight,
        fareType: fareType as string,
        price: fareInfo.price
      });
    }
  };

  // Handle adding flight to trip
  const handleAddToTrip = () => {
    if (selectedFlight) {
      onFlightSelect(selectedFlight.flight, 'outbound');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-7xl h-[90vh] flex flex-col border border-gray-200">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-xl">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <Plane size={20} className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-sf-bold">Flight Search Results</h2>
              <p className="text-blue-100 text-sm font-sf-medium">
                {searchData.from.split(' - ')[1]} to {searchData.to.split(' - ')[1]} • {formatDateDisplay(searchData.departureDate)}
                {searchData.tripType === 'round-trip' && ` - ${formatDateDisplay(searchData.returnDate || '')}`}
                {searchData.passengers && (
                  <span className="ml-2">
                    • {searchData.passengers.adults} Adult{searchData.passengers.adults > 1 ? 's' : ''}
                    {searchData.passengers.children > 0 && `, ${searchData.passengers.children} Child${searchData.passengers.children > 1 ? 'ren' : ''}`}
                    {searchData.passengers.infants > 0 && `, ${searchData.passengers.infants} Infant${searchData.passengers.infants > 1 ? 's' : ''}`}
                    • {searchData.travelClass?.charAt(0).toUpperCase() + searchData.travelClass?.slice(1)}
                  </span>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {selectedOutbound && onContinue && (
              <button
                onClick={() => onContinue({ 
                  outbound: selectedOutbound, 
                  return: searchData.tripType === 'round-trip' ? selectedReturn : null 
                })}
                className={`px-6 py-2 rounded-lg font-sf-semibold transition-colors ${
                  (searchData.tripType === 'one-way' || selectedReturn) 
                    ? 'bg-green-600 hover:bg-green-700 text-white' 
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
                disabled={searchData.tripType === 'round-trip' && !selectedReturn}
              >
                Continue
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors text-sm font-sf-semibold"
            >
              Done
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <X size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Filters Sidebar - Fixed 20% width */}
          <div className="w-1/5 bg-gray-50 border-r border-gray-200 flex-shrink-0 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 140px)' }}>
            <div className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <Filter size={20} className="text-gray-600" />
                <span className="font-sf-bold text-gray-800">Filters</span>
              </div>

              <div className="space-y-6">
                {/* Quick Filters */}
                <div>
                  <h3 className="font-sf-bold text-gray-800 mb-3">Quick Filters</h3>
                  <div className="space-y-2">
                    <button 
                      onClick={() => setFilters(prev => ({ ...prev, stops: 'non-stop' }))}
                      className={`w-full px-3 py-2 text-sm rounded-lg transition-colors ${filters.stops === 'non-stop' ? 'bg-blue-100 text-blue-700' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                    >
                      Non-stop
                    </button>
                    <button 
                      onClick={() => setFilters(prev => ({ ...prev, refundable: !prev.refundable }))}
                      className={`w-full px-3 py-2 text-sm rounded-lg transition-colors ${filters.refundable ? 'bg-blue-100 text-blue-700' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                    >
                      Refundable
                    </button>
                  </div>
                </div>

                {/* Airlines */}
                <div>
                  <h3 className="font-sf-bold text-gray-800 mb-3">Airlines</h3>
                  <div className="space-y-2">
                    {[
                      { code: '6E', name: 'IndiGo', count: 8 },
                      { code: 'SG', name: 'SpiceJet', count: 6 },
                      { code: 'AI', name: 'Air India', count: 4 },
                      { code: 'UK', name: 'Vistara', count: 3 }
                    ].map((airline) => (
                      <label key={airline.code} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.airlines.includes(airline.code)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFilters(prev => ({ ...prev, airlines: [...prev.airlines, airline.code] }));
                              } else {
                                setFilters(prev => ({ ...prev, airlines: prev.airlines.filter(a => a !== airline.code) }));
                              }
                            }}
                            className="text-blue-600 focus:ring-blue-500"
                          />
                          <span className="text-sm font-sf-medium text-gray-700">{airline.name}</span>
                        </div>
                        <span className="text-xs text-gray-500">{airline.count}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Price Range */}
                <div>
                  <h3 className="font-sf-bold text-gray-800 mb-3">Price Range</h3>
                  <input
                    type="range"
                    min="1000"
                    max="100000"
                    step="1000"
                    value={filters.maxPrice}
                    onChange={(e) => setFilters(prev => ({ ...prev, maxPrice: parseInt(e.target.value) }))}
                    className="w-full accent-blue-600"
                  />
                  <div className="flex justify-between text-xs text-gray-600 mt-1">
                    <span>₹1,000</span>
                    <span>{formatPrice(filters.maxPrice)}</span>
                  </div>
                </div>

                {/* Departure Time */}
                <div>
                  <h3 className="font-sf-bold text-gray-800 mb-3">Departure Time</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { value: 'morning', label: 'Morning', time: '6AM-12PM', icon: '🌅' },
                      { value: 'afternoon', label: 'Afternoon', time: '12PM-6PM', icon: '☀️' },
                      { value: 'evening', label: 'Evening', time: '6PM-12AM', icon: '🌆' },
                      { value: 'night', label: 'Night', time: '12AM-6AM', icon: '🌙' }
                    ].map((time) => (
                      <button
                        key={time.value}
                        onClick={() => setFilters(prev => ({ 
                          ...prev, 
                          departureTime: prev.departureTime === time.value ? 'all' : time.value as any 
                        }))}
                        className={`p-2 text-xs rounded-lg border transition-colors ${
                          filters.departureTime === time.value 
                            ? 'border-blue-500 bg-blue-50 text-blue-700' 
                            : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        <div className="text-base mb-1">{time.icon}</div>
                        <div className="font-sf-semibold">{time.label}</div>
                        <div className="text-gray-500">{time.time}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Stops */}
                <div>
                  <h3 className="font-sf-bold text-gray-800 mb-3">Stops</h3>
                  <div className="space-y-2">
                    {[
                      { value: 'all', label: 'All' },
                      { value: 'non-stop', label: 'Non-stop' },
                      { value: '1-stop', label: '1 Stop' },
                      { value: '2+stops', label: '2+ Stops' }
                    ].map((stop) => (
                      <label key={stop.value} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name="stops"
                          value={stop.value}
                          checked={filters.stops === stop.value}
                          onChange={(e) => setFilters(prev => ({ ...prev, stops: e.target.value as any }))}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span className="text-sm font-sf-medium text-gray-700">{stop.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content - 80% width */}
          <div className="flex-1 flex flex-col">
            {/* Sort and Results Header */}
            <div className="p-4 border-b border-gray-200 bg-white">
              <div className="flex items-center justify-between">
                <div className="text-sm font-sf-medium text-gray-600">
                  {loading ? 'Searching flights...' : `${filteredFlights.length} flights found`}
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-sm font-sf-medium text-gray-600">Sort by:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="px-3 py-1 border border-gray-300 rounded-lg text-sm font-sf-medium focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="price">Price</option>
                    <option value="duration">Duration</option>
                    <option value="departure">Departure Time</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Flight Cards */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600 font-sf-medium">Searching for the best flights...</p>
                  </div>
                </div>
              ) : filteredFlights.length === 0 ? (
                <div className="flex items-center justify-center h-64">
                  <div className="text-center">
                    <Plane size={48} className="text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 font-sf-medium">No flights found matching your criteria</p>
                    <p className="text-gray-500 text-sm mt-2">Try adjusting your filters</p>
                    <p className="text-xs text-gray-400 mt-1">Total: {outboundFlights.length}, Filtered: {filteredFlights.length}</p>
                  </div>
                </div>
              ) : (
                renderFlightList(filteredFlights)
              )}
            </div>

            {/* Selected Flight Summary */}
            {selectedFlight && (
              <div className="border-t border-gray-200 bg-white p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="text-2xl">{selectedFlight.flight.airline.logo}</div>
                    <div>
                      <div className="font-sf-bold text-gray-900 text-sm">
                        {selectedFlight.flight.airline.name} {selectedFlight.flight.flightNumber}
                      </div>
                      <div className="text-xs text-gray-600">
                        {selectedFlight.flight.departure.airport} → {selectedFlight.flight.arrival.airport} • {selectedFlight.flight.duration}
                      </div>
                      <div className="text-xs text-gray-500">
                        {formatDateDisplay(searchData.departureDate)} • {selectedFlight.fareType.charAt(0).toUpperCase() + selectedFlight.fareType.slice(1)} Fare
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-lg font-sf-bold text-gray-900">
                        {formatPrice(selectedFlight.price)}
                      </div>
                      <div className="text-xs text-gray-500">per person</div>
                    </div>
                    <button
                      onClick={handleAddToTrip}
                      className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-sf-semibold rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl"
                    >
                      Add to Trip
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlightSearchModal;
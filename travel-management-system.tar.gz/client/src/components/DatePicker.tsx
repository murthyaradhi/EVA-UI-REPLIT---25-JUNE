import React, { forwardRef, useImperativeHandle, useRef, useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

interface DatePickerProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
  placeholder?: string;
  minDate?: string;
  disabled?: boolean;
  isIncomplete?: boolean;
  tabIndex?: number;
}

export interface DatePickerRef {
  openCalendar: () => void;
  focus: () => void;
}

const DatePicker = forwardRef<DatePickerRef, DatePickerProps>(({
  label,
  value,
  onChange,
  required = false,
  placeholder = 'Select date',
  minDate,
  disabled = false,
  isIncomplete = false,
  tabIndex
}, ref) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  // Expose methods to parent component
  useImperativeHandle(ref, () => ({
    openCalendar: () => {
      if (!disabled) {
        setIsCalendarOpen(true);
      }
    },
    focus: () => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  }), [disabled]);

  const handleDateSelect = (date: Date) => {
    const formattedDate = date.toISOString().split('T')[0];
    onChange(formattedDate);
    setIsCalendarOpen(false);
  };

  const handleInputClick = () => {
    if (!disabled) {
      setIsCalendarOpen(true);
    }
  };

  // Calculate minimum date
  const minimumDate = minDate ? new Date(minDate) : new Date();
  const today = new Date();
  const selectedDate = value ? new Date(value) : null;

  const formatDateForDisplay = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];

    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }

    return days;
  };

  const isDateDisabled = (date: Date) => {
    return date < minimumDate;
  };

  const isToday = (date: Date) => {
    return date.toDateString() === today.toDateString();
  };

  const isSelected = (date: Date) => {
    return selectedDate && date.toDateString() === selectedDate.toDateString();
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => {
      const newMonth = new Date(prev);
      if (direction === 'prev') {
        newMonth.setMonth(prev.getMonth() - 1);
      } else {
        newMonth.setMonth(prev.getMonth() + 1);
      }
      return newMonth;
    });
  };

  const getNextMonth = (date: Date) => {
    const nextMonth = new Date(date);
    nextMonth.setMonth(date.getMonth() + 1);
    return nextMonth;
  };

  const CalendarMonth = ({ monthDate }: { monthDate: Date }) => {
    const days = getDaysInMonth(monthDate);
    const monthName = monthDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

    return (
      <div className="p-4">
        <div className="text-center font-sf-semibold text-gray-900 mb-4">{monthName}</div>
        <div className="grid grid-cols-7 gap-1 mb-2">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="text-center text-xs font-sf-medium text-gray-500 py-2 w-8">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {days.map((date, index) => (
            <div key={index} className="w-8 h-8">
              {date && (
                <button
                  type="button"
                  onClick={() => !isDateDisabled(date) && handleDateSelect(date)}
                  disabled={disabled || isDateDisabled(date)}
                  className={`w-full h-full rounded-lg text-sm font-sf-medium transition-all duration-200 flex items-center justify-center ${
                    isSelected(date)
                      ? 'bg-blue-600 text-white shadow-lg'
                      : isToday(date)
                      ? 'bg-blue-100 text-blue-800 ring-2 ring-blue-200'
                      : isDateDisabled(date)
                      ? 'text-gray-300 cursor-not-allowed'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  {date.getDate()}
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div>
      <label className="block text-sm font-sf-semibold text-gray-800 mb-2">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      
      <div className="relative">
        <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none z-10">
          <Calendar size={16} />
        </div>
        <input
          ref={inputRef}
          type="text"
          value={formatDateForDisplay(value)}
          onClick={handleInputClick}
          tabIndex={tabIndex}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleInputClick();
            } else if (e.key === 'Tab' && value && label === 'End Date') {
              // After Tab from End Date, focus should go to services
              setTimeout(() => {
                const firstServiceButton = document.querySelector('[data-service-button]') as HTMLElement;
                if (firstServiceButton) {
                  firstServiceButton.focus();
                }
              }, 0);
            }
          }}
          readOnly
          disabled={disabled}
          required={required}
          placeholder={placeholder}
          className={`w-full pl-11 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 text-sm font-sf-medium bg-white hover:border-gray-400 cursor-pointer text-gray-900 min-h-[48px] ${
            disabled ? 'opacity-50 cursor-not-allowed bg-gray-50' : ''
          }`}
          aria-label={`${label}${required ? ' (required)' : ''}`}
        />
        
        {/* Custom Calendar Dropdown */}
        {isCalendarOpen && (
          <>
            <div 
              className="fixed inset-0 z-[9997]" 
              onClick={() => setIsCalendarOpen(false)}
            />
            <div className="absolute top-full left-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-xl z-[9998] w-[600px]">
              <div className="flex items-center justify-between p-4 border-b border-gray-200">
                <button
                  type="button"
                  onClick={() => navigateMonth('prev')}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                >
                  <ChevronLeft size={20} className="text-gray-600" />
                </button>
                <div className="text-lg font-sf-semibold text-gray-900">
                  Calendar
                </div>
                <button
                  type="button"
                  onClick={() => navigateMonth('next')}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                >
                  <ChevronRight size={20} className="text-gray-600" />
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-0">
                <div className="min-w-[280px]">
                  <CalendarMonth monthDate={currentMonth} />
                </div>
                <div className="border-l border-gray-200 min-w-[280px]">
                  <CalendarMonth monthDate={getNextMonth(currentMonth)} />
                </div>
              </div>
              
              <div className="p-4 border-t border-gray-200 bg-gray-50 text-center">
                <p className="text-xs text-gray-500 font-sf-medium">
                  Click a date to select • Today is highlighted in light blue
                </p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
});

DatePicker.displayName = 'DatePicker';

export default DatePicker;